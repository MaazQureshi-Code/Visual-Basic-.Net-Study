﻿
Imports System.Data.SqlClient
Public Class Form1
    Dim cn As New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Vius basic project\Database\s.mdf;Integrated Security=True;Connect Timeout=30")
    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        cn.Close()
        Application.Exit()
    End Sub
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cn.Open()
    End Sub
    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        display()
    End Sub
    Private Sub DataGridView1_DoubleClick(sender As Object, e As EventArgs) Handles DataGridView1.DoubleClick
        TextBox1.Text = DataGridView1.CurrentRow.Cells("id").Value
        TextBox2.Text = DataGridView1.CurrentRow.Cells("staff").Value
        TextBox3.Text = DataGridView1.CurrentRow.Cells("name").Value
        TextBox7.Text = DataGridView1.CurrentRow.Cells("phone").Value
        ComboBox1.Text = DataGridView1.CurrentRow.Cells("department").Value

    End Sub
    Sub display()
        Try
            If cn.State = ConnectionState.Closed Then
                cn.Open()
            End If

            Dim query As String = "SELECT * FROM myTable"
            Dim command As New SqlCommand(query, cn)
            Dim DT As New DataTable
            Dim SDAdapter As New SqlDataAdapter(command)

            SDAdapter.Fill(DT)
            DataGridView1.DataSource = DT

        Catch ex As Exception
            MessageBox.Show($"Error: {ex.Message}")

        End Try

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            If cn.State = ConnectionState.Closed Then
                cn.Open()
            End If
            Dim Query As String
            Query = "INSERT INTO myTable VALUES('" & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" & ComboBox1.Text & "','" & ComboBox1.Text & "')"
            Dim Command As New SqlCommand(Query, cn)

            Command.ExecuteNonQuery()
            MessageBox.Show("The record is successfully insert it ")
            display()
        Catch ex As Exception
            MessageBox.Show("Error: This has problem " & ex.Message)
        End Try
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Try
            Dim Q As String
            Q = "Select * from myTable WHERE staff='" & TextBox4.Text & "'"
            Dim C As New SqlCommand(Q, cn)
            Dim DT As New DataTable
            Dim SDA As New SqlDataAdapter(C)
            SDA.Fill(DT)
            DataGridView1.DataSource = DT
            DataGridView1.Refresh()
        Catch ex As Exception
            MessageBox.Show("Error: This has problem  " & ex.Message)
        End Try
    End Sub






End Class
