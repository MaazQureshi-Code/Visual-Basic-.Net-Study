﻿CREATE TABLE [dbo].[myTable]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [staff] NCHAR(10) NULL, 
    [name] NCHAR(10) NULL, 
    [phone] NCHAR(10) NULL, 
    [Department] NCHAR(10) NULL
)
